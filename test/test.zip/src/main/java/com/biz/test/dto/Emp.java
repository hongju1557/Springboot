package com.biz.test.dto;

import lombok.Data;

@Data
public class Emp {

    private int empId;
    private String empName;
    private String email;
    private String deptId;
    private String jobCode;
    private int salary;
    private String hireDate;
}